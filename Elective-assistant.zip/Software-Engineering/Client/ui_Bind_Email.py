# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui_Bind_Email.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_Bind(object):
    def setupUi(self, Bind):
        Bind.setObjectName("Bind")
        Bind.resize(400, 270)
        Bind.setMinimumSize(QtCore.QSize(400, 270))
        Bind.setMaximumSize(QtCore.QSize(400, 270))
        self.email = QtWidgets.QLineEdit(Bind)
        self.email.setGeometry(QtCore.QRect(90, 50, 221, 33))
        font = QtGui.QFont()
        font.setFamily("SimSun-ExtB")
        font.setPointSize(10)
        self.email.setFont(font)
        self.email.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.email.setText("")
        self.email.setMaxLength(100)
        self.email.setObjectName("email")
        self.affirm = QtWidgets.QPushButton(Bind)
        self.affirm.setEnabled(True)
        self.affirm.setGeometry(QtCore.QRect(150, 222, 91, 28))
        self.affirm.setObjectName("affirm")
        self.verifiaction = QtWidgets.QLineEdit(Bind)
        self.verifiaction.setGeometry(QtCore.QRect(90, 130, 111, 33))
        font = QtGui.QFont()
        font.setFamily("SimSun-ExtB")
        font.setPointSize(10)
        self.verifiaction.setFont(font)
        self.verifiaction.setFocusPolicy(QtCore.Qt.ClickFocus)
        self.verifiaction.setText("")
        self.verifiaction.setMaxLength(6)
        self.verifiaction.setObjectName("verifiaction")
        self.getVf = QtWidgets.QPushButton(Bind)
        self.getVf.setGeometry(QtCore.QRect(220, 130, 81, 28))
        font = QtGui.QFont()
        font.setBold(False)
        font.setItalic(False)
        font.setUnderline(True)
        font.setWeight(50)
        self.getVf.setFont(font)
        self.getVf.setFlat(True)
        self.getVf.setObjectName("getVf")

        self.retranslateUi(Bind)
        QtCore.QMetaObject.connectSlotsByName(Bind)

    def retranslateUi(self, Bind):
        _translate = QtCore.QCoreApplication.translate
        Bind.setWindowTitle(_translate("Bind", "注册"))
        self.email.setPlaceholderText(_translate("Bind", "请输入绑定的邮箱账号"))
        self.affirm.setText(_translate("Bind", "确定"))
        self.verifiaction.setPlaceholderText(_translate("Bind", "验证码"))
        self.getVf.setText(_translate("Bind", "获取验证码"))

