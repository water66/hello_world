#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2018/5/24 23:23
# @Author  : October
# @Site    : 
# @File    : GlobalVariable.py
# @Software: PyCharm

# 套接字
SOCKET = None

# 窗口
WIN_LOGIN = None
WIN_BIND = None
WIN_FORGET = None
WIN_MAIN = None
WIDGET = None

# 账号类型
TYPE = None







