#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2018/5/27 22:04
# @Author  : October
# @Site    : 
# @File    : lg_Schedule.py
# @Software: PyCharm

from PyQt5.QtWidgets import QWidget, QTableWidgetItem, QMessageBox
from PyQt5.QtCore import Qt, QDataStream
from ui_Schedule import Ui_Schedule
from NetLinkProcess import NetLinkProcess as NLP
import Constants as CONST
import GlobalVariable as GV


class Lg_Schedule(QWidget, Ui_Schedule):

    def __init__(self, parent=None):
        super(Lg_Schedule, self).__init__(parent)
        self.setupUi(self)
        self.theWeek = 0
        self.wholeSchedule = True
        self.nextBlockSize = 0
        # 信号与槽
        GV.SOCKET.readyRead.connect(self.readResponse)
        self.quickFind.clicked.connect(self.on_quickFind_Clicked)
        self.whole.clicked.connect(self.on_whole_Clicked)
        self.courseTable.itemChanged.connect(self.courseTable.resizeRowsToContents)
        # 初始化时自动请求所有课程成绩
        NLP.sendRequest(GV.SOCKET, CONST.WHOLE)


    def on_quickFind_Clicked(self):
        self.wholeSchedule = False
        self.theWeek = int(self.week.text())
        NLP.sendRequest(GV.SOCKET, CONST.WHOLE)


    def on_whole_Clicked(self):
        self.wholeSchedule = True
        NLP.sendRequest(GV.SOCKET, CONST.WHOLE)


    # 读取相应数据
    def readResponse(self):
        stream = QDataStream(GV.SOCKET)
        stream.setVersion(QDataStream.Qt_5_7)

        while True:
            if self.nextBlockSize == 0:
                if GV.SOCKET.bytesAvailable() < CONST.SIZEOF_UINT16:
                    break
                self.nextBlockSize = stream.readUInt16()
            if GV.SOCKET.bytesAvailable() < self.nextBlockSize:
                break
            self.nextBlockSize = 0
            response = stream.readQString()
            self.handleResponse(response)


    def handleResponse(self , response):
        response = response.split('+')
        action = response.pop(0)
        # 显示课表
        if action == CONST.WHOLE:
            self.clear()
            response = NLP.Unpack(response[0])
            for course in response:
                first = True
                # 显示全部课程
                if self.wholeSchedule:
                    items = course.split('|')[1:]
                    weekday = int(items[3])
                    section = int(items[4].split(',')[0])
                    # 将周次转化为语句表示
                    weeks = items[2].split(',')
                    weeks = [int(week) for week in weeks]
                    start = weeks[0]
                    end = weeks[0]
                    str_weeks = ""
                    for each in weeks:
                        if each == end:
                            end += 1
                        else:
                            if start == end - 1:
                                if str_weeks == "":
                                    str_weeks = str(start)
                                else:
                                    str_weeks = str_weeks + ',' + str(start)
                            else:
                                if str_weeks == "":
                                    str_weeks = str(start) + '-' + str(end - 1)
                                else:
                                    str_weeks = str_weeks + ',' + str(start) + '-' + str(end - 1)
                    if start == end - 1:
                        if str_weeks == "":
                            str_weeks = str(start)
                        else:
                            str_weeks = str_weeks + ',' + str(start)
                    else:
                        if str_weeks == "":
                            str_weeks = str(start) + '-' + str(end - 1)
                        else:
                            str_weeks = str_weeks + ',' + str(start) + '-' + str(end - 1)
                    str_weeks = str_weeks + "周"
                    # 向表中添加内容
                    newItem = QTableWidgetItem(items[0] + '\n' + items[1] + '\n' + str_weeks + '\n' + items[5])
                    newItem.setTextAlignment(Qt.AlignHCenter | Qt.AlignVCenter)
                    if first:
                        if section < 4:
                            self.courseTable.setItem(section - 1, weekday, newItem)
                        else:
                            self.courseTable.setItem(section, weekday, newItem)
                        first = False
                    else:
                        if section < 4:
                            self.courseTable.setItem(section + 1, weekday, newItem)
                        else:
                            self.courseTable.setItem(section + 2, weekday, newItem)
                # 显示指定周次课程
                else:
                    items = course.split('|')[1:]
                    weekday = int(items[3])
                    section = int(items[4].split(',')[0])
                    weeks = items[2].split(',')
                    weeks = [int(week) for week in weeks]
                    if self.theWeek in weeks:
                        newItem = QTableWidgetItem(items[0] + '\n' + items[1] + '\n' + items[5])
                        newItem.setTextAlignment(Qt.AlignHCenter | Qt.AlignVCenter)
                        if first:
                            if section < 4:
                                self.courseTable.setItem(section - 1, weekday, newItem)
                            else:
                                self.courseTable.setItem(section, weekday, newItem)
                            first = False
                        else:
                            if section < 4:
                                self.courseTable.setItem(section + 1, weekday, newItem)
                            else:
                                self.courseTable.setItem(section + 2, weekday, newItem)
        # 显示交互信息
        elif action == CONST.FALSE:
            if response[0] == CONST.WHOLE:
                QMessageBox.question(self, "提示", "查询失败   ", QMessageBox.Yes, QMessageBox.Yes)


    # 清空课表的内容
    def clear(self):
        for r in range(4):
            for c in range(7)[1:]:
                item = self.courseTable.item(r, c)
                if not item is None:
                    item.setText("")
        for r in range(10)[5:]:
            for c in range(7)[1:]:
                item = self.courseTable.item(r, c)
                if not item is None:
                    item.setText("")

    # 关闭
    def closeEvent(self, QCloseEvent):
        GV.SOCKET.readyRead.disconnect(self.readResponse)



if __name__ == '__main__':
    import sys
    from PyQt5.QtWidgets import QApplication

    app = QApplication(sys.argv)

    win = Lg_Schedule()
    win.show()

    app.exit(app.exec_())



