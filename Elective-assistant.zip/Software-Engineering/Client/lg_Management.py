#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2018/5/27 20:30
# @Author  : October
# @Site    : 
# @File    : lg_Management.py
# @Software: PyCharm

from PyQt5.QtWidgets import QWidget, QTableWidget, QTableWidgetItem, QCheckBox, QMessageBox
from PyQt5.QtCore import Qt, QDataStream, pyqtSignal
from ui_Management import Ui_Management
from NetLinkProcess import NetLinkProcess as NLP
import Constants as CONST
import GlobalVariable as GV


class Lg_Management(QWidget, Ui_Management):
    # 判断当前页面是否准备好，若准备好则使确认键可用
    readyOperate = pyqtSignal()

    def __init__(self, parent=None):
        super(Lg_Management, self).__init__(parent)
        self.setupUi(self)
        self.nextBlockSize = 0
        self.SelectCourse = True    # 选课模式
        self.SelectedCourse = False    # 已选课程模式
        self.QuitCourse = False     # 退课模式
        # 绑定信号与槽函数
        GV.SOCKET.readyRead.connect(self.readResponse)
        self.select.clicked.connect(self.on_select_Clicked)     # 选课
        self.course.clicked.connect(self.on_course_Clicked)     # 已选课程
        self.withback.clicked.connect(self.on_withback_Clicked)     # 退课
        self.affirm.clicked.connect(self.on_affirm_Clicked)     # 确认
        self.readyOperate.connect(self.set_affirm_enabled)    # 使确认键可用
        # 初始化时自动请求可选课程信息
        NLP.sendRequest(GV.SOCKET, CONST.SELECT)


    # 选课
    def on_select_Clicked(self):
        self.affirm.setEnabled(False)
        self.SelectCourse = True    # 当前为选课模式
        self.SelectedCourse = False
        self.QuitCourse = False
        NLP.sendRequest(GV.SOCKET, CONST.SELECT)


    # 已选课程
    def on_course_Clicked(self):
        self.affirm.setEnabled(False)
        self.SelectCourse = False
        self.SelectedCourse = True
        self.QuitCourse = False
        NLP.sendRequest(GV.SOCKET, CONST.SELECTED_COURSE)


    # 退课
    def on_withback_Clicked(self):
        self.affirm.setEnabled(False)
        self.SelectCourse = False
        self.SelectedCourse = False
        self.QuitCourse = True   # 当前为退课模式
        NLP.sendRequest(GV.SOCKET, CONST.SELECTED_COURSE)


    # 确认
    def on_affirm_Clicked(self):
        courses = []
        # 获取被选中的课程号
        row_count = self.courseTable.rowCount()
        for i in range(row_count):
            if type(self.courseTable.cellWidget(i, 9)) is QCheckBox:
                if self.courseTable.cellWidget(i, 9).isChecked():
                    self.courseTable.cellWidget(i, 9).setChecked(False)
                    c = self.courseTable.item(i, 0).text()
                    courses.append(c.split()[0])
        if len(courses) == 0:
            return
        # 选课
        if self.SelectCourse:
            courses.insert(0, CONST.SELECT_COURSE)
            NLP.sendRequest(GV.SOCKET, NLP.Packge(courses))
        # 退课
        elif self.QuitCourse:
            courses.insert(0, CONST.QUIT_COURSE)
            NLP.sendRequest(GV.SOCKET, NLP.Packge(courses))


    # 读取服务器响应的数据
    def readResponse(self):
        stream = QDataStream(GV.SOCKET)
        stream.setVersion(QDataStream.Qt_5_7)

        while True:
            if self.nextBlockSize == 0:
                if GV.SOCKET.bytesAvailable() < CONST.SIZEOF_UINT16:
                    break
                self.nextBlockSize = stream.readUInt16()
            if GV.SOCKET.bytesAvailable() < self.nextBlockSize:
                break
            self.nextBlockSize = 0
            response = stream.readQString()
            self.handleResponse(response)

    # 处理响应数据
    def handleResponse(self, response):
        response = response.split('+')
        action = response.pop(0)
        # 显示可选课程信息或显示已选课程信息
        if action == CONST.SELECT or action == CONST.SELECTED_COURSE:
            row_count = self.courseTable.rowCount()
            for r in range(row_count):
                self.courseTable.removeRow(0)   # 先清空表格
            temp_course = NLP.Unpack(response[0])
            temp_schedule = NLP.Unpack(response[1])
            course = []
            schedule = []
            for item in temp_course:
                item = item.split('|')
                item.pop(0)
                course.append(item)
            for item in temp_schedule:
                item = item.split('|')
                item.pop(0)
                schedule.append(item)
            for courseItem in course:
                empty = True
                start_row_count = self.courseTable.rowCount()
                self.courseTable.insertRow(start_row_count)  # 添加一行
                checkBox = QCheckBox()
                self.courseTable.setCellWidget(start_row_count, 9, checkBox)
                col = 0
                for citem in courseItem:
                    newItem = QTableWidgetItem("      " + citem + "      ")
                    newItem.setTextAlignment(Qt.AlignHCenter | Qt.AlignVCenter)
                    self.courseTable.setItem(start_row_count, col, newItem)
                    col += 1
                # 分行显示
                for scheduleItem in schedule:
                    if scheduleItem[0] == courseItem[0]:
                        if not empty:
                            end_row_count = self.courseTable.rowCount()
                            self.courseTable.insertRow(end_row_count)  # 添加一行
                        temp_col = col
                        for sitem in scheduleItem[1:]:
                            empty = False
                            if not temp_col == 5:
                                newItem = QTableWidgetItem("      " + sitem + "      ")
                                newItem.setTextAlignment(Qt.AlignHCenter | Qt.AlignVCenter)
                                end_row_count = self.courseTable.rowCount()
                                self.courseTable.setItem(end_row_count - 1, temp_col, newItem)
                            else:
                                # 将周次转化为语句表示
                                weeks = sitem.split(',')
                                weeks = [int(week) for week in weeks]
                                start = weeks[0]
                                end = weeks[0]
                                str_weeks = ""
                                for each in weeks:
                                    if each == end:
                                        end += 1
                                    else:
                                        if start == end - 1:
                                            if str_weeks == "":
                                                str_weeks = str(start)
                                            else:
                                                str_weeks = str_weeks + ',' + str(start)
                                        else:
                                            if str_weeks == "":
                                                str_weeks = str(start) + '-' + str(end - 1)
                                            else:
                                                str_weeks = str_weeks + ',' + str(start) + '-' + str(end - 1)
                                if start == end - 1:
                                    if str_weeks == "":
                                        str_weeks = str(start)
                                    else:
                                        str_weeks = str_weeks + ',' + str(start)
                                else:
                                    if str_weeks == "":
                                        str_weeks = str(start) + '-' + str(end - 1)
                                    else:
                                        str_weeks = str_weeks + ',' + str(start) + '-' + str(end - 1)
                                str_weeks = str_weeks + "周"
                                newItem = QTableWidgetItem("      " + str_weeks + "      ")
                                newItem.setTextAlignment(Qt.AlignHCenter | Qt.AlignVCenter)
                                end_row_count = self.courseTable.rowCount()
                                self.courseTable.setItem(end_row_count - 1, temp_col, newItem)
                            temp_col += 1
                            end_row_count = self.courseTable.rowCount()
                            for i in range(5):
                                self.courseTable.setSpan(start_row_count, i, end_row_count - start_row_count, 1)
                            self.courseTable.setSpan(start_row_count, 9, end_row_count - start_row_count, 1)
            self.courseTable.resizeColumnsToContents()  # 自动调整单元格宽度
            self.courseTable.horizontalHeader().setStretchLastSection(True) # 最后一列填充满表格
            self.courseTable.setSelectionBehavior(QTableWidget.SelectRows)  # 设置为一次选中一行
            # 当前页面已准备好，使确认键可用
            self.readyOperate.emit()
        # 显示交互信息
        elif action == CONST.TRUE:
            if response[0] == CONST.SELECT_COURSE:
                QMessageBox.question(self, "提示", "选课成功   ", QMessageBox.Yes, QMessageBox.Yes)
            elif response[0] == CONST.QUIT_COURSE:
                QMessageBox.question(self, "提示", "退课成功   ", QMessageBox.Yes, QMessageBox.Yes)
        elif action == CONST.FALSE:
            if response[0] == CONST.SELECT or response[0] == CONST.SELECTED_COURSE:
                QMessageBox.question(self, "提示", "响应失败   ", QMessageBox.Yes, QMessageBox.Yes)
            elif response[0] == CONST.SELECT_COURSE:
                QMessageBox.question(self, "提示", "选课失败   ", QMessageBox.Yes, QMessageBox.Yes)
            elif response[0] == CONST.QUIT_COURSE:
                QMessageBox.question(self, "提示", "退课失败   ", QMessageBox.Yes, QMessageBox.Yes)


    # 使确认键可用
    def set_affirm_enabled(self):
        if self.SelectedCourse:
            return
        self.affirm.setEnabled(True)

    # 关闭窗口
    def closeEvent(self, QCloseEvent):
        GV.SOCKET.readyRead.disconnect(self.readResponse)
