#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2018/6/5 19:57
# @Author  : October
# @Site    : 
# @File    : lg_Forget_Password.py
# @Software: PyCharm

from PyQt5.QtWidgets import QFrame, QMessageBox
from PyQt5.QtCore import QDataStream, pyqtSignal
from ui_Forget_Password import Ui_Forget
from lg_Login import Lg_Login
from NetLinkProcess import NetLinkProcess as NLP
import GlobalVariable as GV
import Constants as CONST


class Lg_Forget(QFrame, Ui_Forget):
    modifySuccessfully = pyqtSignal()

    def __init__(self, parent=None):
        super(Lg_Forget, self).__init__(parent)
        self.setupUi(self)
        self.nextBlockSize = 0
        # 信号与槽
        GV.SOCKET.readyRead.connect(self.readResponse)
        self.affirm.clicked.connect(self.on_affirm_Clicked)
        self.getVf.clicked.connect(self.on_getVf_Clicked)


    # 确认
    def on_affirm_Clicked(self):
        _id = self.id.text()
        _password = self.password.text()
        _repeat = self.repeat.text()
        _vf = self.verifiaction.text()
        if _id == '':
            QMessageBox.question(self, "提示", "学工号不能为空   ", QMessageBox.Yes, QMessageBox.Yes)
            return
        elif _password == '':
            QMessageBox.question(self, "提示", "密码不能为空   ", QMessageBox.Yes, QMessageBox.Yes)
            return
        elif not _repeat == _password:
            QMessageBox.question(self, "提示", "两次输入的密码不相同   ", QMessageBox.Yes, QMessageBox.Yes)
            return
        elif _vf == '':
            QMessageBox.question(self, "提示", "验证码不能为空   ", QMessageBox.Yes, QMessageBox.Yes)
            return
        request = NLP.Packge([CONST.FORGET_PASSWORD, _id, _password, _vf])
        NLP.sendRequest(GV.SOCKET, request)


    # 获取验证码
    def on_getVf_Clicked(self):
        _id = self.id.text()
        if _id == '':
            QMessageBox.question(self, "提示", "学工号不能为空   ", QMessageBox.Yes, QMessageBox.Yes)
            return
        request = [CONST.FORGET_GET_VF, _id]
        NLP.sendRequest(GV.SOCKET, NLP.Packge(request))


    # 读取服务器响应的数据
    def readResponse(self):
        stream = QDataStream(GV.SOCKET)
        stream.setVersion(QDataStream.Qt_5_7)

        while True:
            if self.nextBlockSize == 0:
                if GV.SOCKET.bytesAvailable() < CONST.SIZEOF_UINT16:
                    break
                self.nextBlockSize = stream.readUInt16()
            if GV.SOCKET.bytesAvailable() < self.nextBlockSize:
                break
            self.nextBlockSize = 0
            response = stream.readQString()
            self.handleResponse(response)


    # 处理消息
    def handleResponse(self, response):
        response = response.split('+')
        action = response.pop(0)

        if action == CONST.TRUE:
            if response[0] == CONST.FORGET_GET_VF:
                QMessageBox.question(self, "提示", "验证码发送成功   ", QMessageBox.Yes, QMessageBox.Yes)
            elif response[0] == CONST.FORGET_PASSWORD:
                QMessageBox.question(self, "提示", "密码修改成功   ", QMessageBox.Yes, QMessageBox.Yes)
                self.modifySuccessfully.emit()
        elif action == CONST.FALSE:
            if response[0] == CONST.FORGET_GET_VF:
                QMessageBox.question(self, "提示", "验证码发送失败，请检查用户名   ", QMessageBox.Yes, QMessageBox.Yes)
            elif response[0] == CONST.FORGET_PASSWORD:
                QMessageBox.question(self, "提示", "密码修改失败  ", QMessageBox.Yes, QMessageBox.Yes)


    # 关闭窗口
    def closeEvent(self, QCloseEvent):
        GV.SOCKET.readyRead.disconnect(self.readResponse)
