# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui_Forget_Password.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_Forget(object):
    def setupUi(self, Forget):
        Forget.setObjectName("Forget")
        Forget.resize(400, 270)
        self.verifiaction = QtWidgets.QLineEdit(Forget)
        self.verifiaction.setGeometry(QtCore.QRect(90, 170, 111, 33))
        font = QtGui.QFont()
        font.setFamily("SimSun-ExtB")
        font.setPointSize(10)
        self.verifiaction.setFont(font)
        self.verifiaction.setFocusPolicy(QtCore.Qt.ClickFocus)
        self.verifiaction.setText("")
        self.verifiaction.setMaxLength(6)
        self.verifiaction.setObjectName("verifiaction")
        self.id = QtWidgets.QLineEdit(Forget)
        self.id.setGeometry(QtCore.QRect(90, 20, 221, 33))
        font = QtGui.QFont()
        font.setFamily("SimSun-ExtB")
        font.setPointSize(10)
        self.id.setFont(font)
        self.id.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.id.setText("")
        self.id.setMaxLength(100)
        self.id.setObjectName("id")
        self.repeat = QtWidgets.QLineEdit(Forget)
        self.repeat.setGeometry(QtCore.QRect(90, 120, 221, 33))
        font = QtGui.QFont()
        font.setFamily("SimSun-ExtB")
        font.setPointSize(10)
        self.repeat.setFont(font)
        self.repeat.setFocusPolicy(QtCore.Qt.ClickFocus)
        self.repeat.setMaxLength(15)
        self.repeat.setEchoMode(QtWidgets.QLineEdit.Password)
        self.repeat.setObjectName("repeat")
        self.password = QtWidgets.QLineEdit(Forget)
        self.password.setGeometry(QtCore.QRect(90, 70, 221, 33))
        font = QtGui.QFont()
        font.setFamily("SimSun-ExtB")
        font.setPointSize(10)
        self.password.setFont(font)
        self.password.setFocusPolicy(QtCore.Qt.ClickFocus)
        self.password.setWhatsThis("")
        self.password.setText("")
        self.password.setMaxLength(15)
        self.password.setEchoMode(QtWidgets.QLineEdit.Password)
        self.password.setObjectName("password")
        self.affirm = QtWidgets.QPushButton(Forget)
        self.affirm.setEnabled(True)
        self.affirm.setGeometry(QtCore.QRect(150, 225, 91, 28))
        self.affirm.setObjectName("affirm")
        self.getVf = QtWidgets.QPushButton(Forget)
        self.getVf.setGeometry(QtCore.QRect(210, 170, 81, 28))
        font = QtGui.QFont()
        font.setBold(False)
        font.setItalic(False)
        font.setUnderline(True)
        font.setWeight(50)
        self.getVf.setFont(font)
        self.getVf.setFlat(True)
        self.getVf.setObjectName("getVf")

        self.retranslateUi(Forget)
        QtCore.QMetaObject.connectSlotsByName(Forget)

    def retranslateUi(self, Forget):
        _translate = QtCore.QCoreApplication.translate
        Forget.setWindowTitle(_translate("Forget", "忘记密码"))
        self.verifiaction.setPlaceholderText(_translate("Forget", "验证码"))
        self.id.setPlaceholderText(_translate("Forget", "学号/工号"))
        self.repeat.setPlaceholderText(_translate("Forget", "确认密码"))
        self.password.setToolTip(_translate("Forget", "<html><head/><body><p><br/></p></body></html>"))
        self.password.setPlaceholderText(_translate("Forget", "输入密码"))
        self.affirm.setText(_translate("Forget", "确定"))
        self.getVf.setText(_translate("Forget", "获取验证码"))

