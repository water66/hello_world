#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2018/5/27 17:52
# @Author  : October
# @Site    : 
# @File    : WindowManage.py
# @Software: PyCharm

from lg_Login import Lg_Login
from lg_Bind_Email import Lg_Bind
from lg_Forget_Password import Lg_Forget
from lg_MainWindow import Lg_MainWindow
from lg_HomePage import Lg_HomePage
from lg_T_HomePage import Lg_T_HomePage
from lg_Management import Lg_Management
from lg_Schedule import Lg_Schedule
from lg_personal import Lg_Personal
from lg_Grade import Lg_Grade
from lg_Info_Management import Lg_Info_Managment
import GlobalVariable as GV
import Constants as CONST


class WindowManage:

    # 登录成功，打开主界面
    @classmethod
    def openMainWindow(cls, state):
        GV.WIN_LOGIN.close()
        GV.WIN_LOGIN = None
        GV.WIN_MAIN = Lg_MainWindow()   # 建立主窗口
        WindowManage.buildMainWindow()  # 绑定信号与槽
        if GV.TYPE == CONST.S:
            GV.WIDGET = Lg_HomePage()
        elif GV.TYPE == CONST.F:
            GV.WIDGET = Lg_T_HomePage()
        WindowManage.buildHomePage()
        GV.WIN_MAIN.updateUI(GV.WIDGET)
        if state == CONST.TRUE:
            GV.WIN_MAIN.show()
        elif state == CONST.FALSE:  # 没有绑定邮箱，先绑定邮箱
            GV.WIN_BIND = Lg_Bind()
            GV.WIN_BIND.show()


    # 忘记密码
    @classmethod
    def forgetPassword(cls):
        GV.WIN_LOGIN.close()
        GV.WIN_LOGIN = None
        GV.WIN_FORGET = Lg_Forget()
        GV.WIN_FORGET.modifySuccessfully.connect(WindowManage.forget_and_modify)
        GV.WIN_FORGET.show()



    # HomePage
    @classmethod
    def buildHomePage(cls):
        if GV.TYPE == CONST.S:
            GV.WIDGET.management.clicked.connect(WindowManage.on_management_Clicked)
            GV.WIDGET.schedule.clicked.connect(WindowManage.on_schedule_Clicked)
            GV.WIDGET.grade.clicked.connect(WindowManage.on_grade_Clicked)
            GV.WIDGET.personal.clicked.connect(WindowManage.on_personal_Clicked)
            GV.WIDGET.account.clicked.connect(WindowManage.on_account_Clicked)
        elif GV.TYPE == CONST.F:
            # TODO
            #绑定信号与槽
            pass

    # 选课管理
    @classmethod
    def on_management_Clicked(cls):
        GV.WIDGET.close()
        GV.WIDGET = Lg_Management()
        GV.WIDGET.update()
        GV.WIN_MAIN.updateUI(GV.WIDGET)
        GV.WIN_MAIN.goback.setEnabled(True)

    # 本学期课表
    @classmethod
    def on_schedule_Clicked(cls):
        GV.WIDGET.close()
        GV.WIDGET = Lg_Schedule()
        GV.WIN_MAIN.updateUI(GV.WIDGET)
        GV.WIN_MAIN.goback.setEnabled(True)

    # 查询成绩
    @classmethod
    def on_grade_Clicked(cls):
        GV.WIDGET.close()
        GV.WIDGET = Lg_Grade()
        GV.WIN_MAIN.updateUI(GV.WIDGET)
        GV.WIN_MAIN.goback.setEnabled(True)

    # 个人信息
    @classmethod
    def on_personal_Clicked(cls):
        GV.WIDGET.close()
        GV.WIDGET = Lg_Personal()
        GV.WIN_MAIN.updateUI(GV.WIDGET)
        GV.WIN_MAIN.goback.setEnabled(True)


    # 账户管理
    @classmethod
    def on_account_Clicked(cls):
        GV.WIDGET.close()
        GV.WIDGET = Lg_Info_Managment()
        GV.WIN_MAIN.updateUI(GV.WIDGET)
        GV.WIN_MAIN.goback.setEnabled(True)




    # MainWindow
    @classmethod
    def buildMainWindow(cls):
        GV.WIN_MAIN.goback.clicked.connect(WindowManage.on_goback_Clicked)
        GV.WIN_MAIN.change.clicked.connect(WindowManage.on_change_Clicked)

    # 返回
    @classmethod
    def on_goback_Clicked(cls):
        GV.WIDGET.close()
        if GV.TYPE == CONST.S:
            GV.WIDGET = Lg_HomePage()
        elif GV.TYPE == CONST.F:
            GV.WIDGET = Lg_T_HomePage()
        WindowManage.buildHomePage()
        GV.WIN_MAIN.updateUI(GV.WIDGET)
        GV.WIN_MAIN.goback.setEnabled(False)

    # 切换用户
    @classmethod
    def on_change_Clicked(cls):
        if GV.WIN_MAIN.close():
            GV.WIN_MAIN = None
            GV.WIN_LOGIN = Lg_Login()
            GV.WIN_LOGIN.loginSuccessfully.connect(WindowManage.openMainWindow)
            GV.WIN_LOGIN.forget.clicked.connect(WindowManage.forgetPassword)
            GV.WIN_LOGIN.show()


    # 通过邮箱成功修改密码
    @classmethod
    def forget_and_modify(cls):
        GV.WIN_FORGET.close()
        GV.WIN_FORGET = None
        GV.WIN_LOGIN = Lg_Login()
        GV.WIN_LOGIN.loginSuccessfully.connect(WindowManage.openMainWindow)
        GV.WIN_LOGIN.forget.clicked.connect(WindowManage.forgetPassword)
        GV.WIN_LOGIN.show()



