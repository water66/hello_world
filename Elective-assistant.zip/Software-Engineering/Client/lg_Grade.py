#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2018/5/27 22:09
# @Author  : October
# @Site    : 
# @File    : lg_Grade.py
# @Software: PyCharm

from PyQt5.QtWidgets import QWidget, QTableWidget, QHeaderView, QTableWidgetItem, QMessageBox
from PyQt5.QtCore import Qt, QDataStream
from ui_Grade import Ui_Grade
from NetLinkProcess import NetLinkProcess as NLP
import Constants as CONST
import GlobalVariable as GV


class Lg_Grade(QWidget, Ui_Grade):

    def __init__(self, parent=None):
        super(Lg_Grade, self).__init__(parent)
        self.setupUi(self)
        self.nextBlockSize = 0
        # 信号与槽
        GV.SOCKET.readyRead.connect(self.readResponse)
        self.grade.clicked.connect(self.on_grade_Clicked)
        self.pass_.clicked.connect(self.on_pass__Clicked)
        self.fail.clicked.connect(self.on_fail_Clicked)
        # 初始化时自动请求所有课程成绩
        NLP.sendRequest(GV.SOCKET, CONST.GRADE)


    # 查询所有课程成绩
    def on_grade_Clicked(self):
        NLP.sendRequest(GV.SOCKET, CONST.GRADE)


    # 查询及格课程成绩
    def on_pass__Clicked(self):
        NLP.sendRequest(GV.SOCKET, CONST.PASS)


    # 查询不及格课程成绩
    def on_fail_Clicked(self):
        NLP.sendRequest(GV.SOCKET, CONST.FAIL)


    # 读取相应数据
    def readResponse(self):
        stream = QDataStream(GV.SOCKET)
        stream.setVersion(QDataStream.Qt_5_7)

        while True:
            if self.nextBlockSize == 0:
                if GV.SOCKET.bytesAvailable() < CONST.SIZEOF_UINT16:
                    break
                self.nextBlockSize = stream.readUInt16()
            if GV.SOCKET.bytesAvailable() < self.nextBlockSize:
                break
            self.nextBlockSize = 0
            response = stream.readQString()
            self.handleResponse(response)


    # 处理数据
    def handleResponse(self, response):
        response = response.split('+')
        action = response.pop(0)
        # 显示成绩
        if action == CONST.GRADE or action == CONST.PASS or action == CONST.FAIL:
            row_count = self.gradeTable.rowCount()
            for r in range(row_count):
                self.gradeTable.removeRow(0)  # 先清空表格
            temp_grade = NLP.Unpack(response[0])
            temp_course = NLP.Unpack(response[1])
            grade = []
            course = []
            for item in temp_grade:
                item = item.split('|')
                item.pop(0)
                grade.append(item)
            for item in temp_course:
                item = item.split('|')
                item.pop(0)
                course.append(item)
            for i in range(len(course)):
                row_count = self.gradeTable.rowCount()
                self.gradeTable.insertRow(row_count)  # 添加一行
                col = 0
                for citem in course[i]:
                    newItem = QTableWidgetItem("    " + citem + "    ")
                    newItem.setTextAlignment(Qt.AlignHCenter | Qt.AlignVCenter)
                    self.gradeTable.setItem(row_count, col, newItem)
                    col += 1
                newItem = QTableWidgetItem("    " + grade[i][2] + "    ")
                newItem.setTextAlignment(Qt.AlignHCenter | Qt.AlignVCenter)
                self.gradeTable.setItem(row_count, col, newItem)
            self.gradeTable.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)  # 平均分配每列宽度
            self.gradeTable.setSelectionBehavior(QTableWidget.SelectRows)  # 设置为一次选中一行
        # 显示交互信息
        elif action == CONST.FALSE:
            QMessageBox.question(self, "提示", "查询失败   ", QMessageBox.Yes, QMessageBox.Yes)


    # 关闭窗口
    def closeEvent(self, QCloseEvent):
        GV.SOCKET.readyRead.disconnect(self.readResponse)

