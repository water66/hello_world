#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2018/5/27 15:54
# @Author  : October
# @Site    : 
# @File    : main.py
# @Software: PyCharm

import sys
from PyQt5.QtWidgets import QApplication
from PyQt5.QtNetwork import QTcpSocket
from lg_Login import Lg_Login
from NetLinkProcess import NetLinkProcess as NLP
from WindowManage import WindowManage as WM
import GlobalVariable as GV
import Constants as Const


if __name__ == "__main__":
    app = QApplication(sys.argv)
    # 连接服务器
    GV.SOCKET = QTcpSocket()
    GV.SOCKET.connectToHost(Const.ADDR, Const.PORT)
    GV.SOCKET.connected.connect(NLP.connected)  # 连接成功
    GV.SOCKET.error.connect(NLP.serverError)  # 服务器出错
    GV.SOCKET.disconnected.connect(GV.SOCKET.deleteLater)

    # 登录窗口
    GV.WIN_LOGIN = Lg_Login()
    GV.WIN_LOGIN.loginSuccessfully.connect(WM.openMainWindow)
    GV.WIN_LOGIN.forget.clicked.connect(WM.forgetPassword)
    GV.WIN_LOGIN.show()

    app.exec_()

