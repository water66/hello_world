#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2018/6/4 20:44
# @Author  : October
# @Site    : 
# @File    : lg_School_Info.py
# @Software: PyCharm

from PyQt5.QtWidgets import QWidget
from ui_School_Info import Ui_School_Info


class Lg_School_Info(QWidget, Ui_School_Info):

    def __init__(self, parent=None):
        super(Lg_School_Info, self).__init__(parent)
        self.setupUi(self)
