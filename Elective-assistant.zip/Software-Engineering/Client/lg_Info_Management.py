#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2018/6/5 18:52
# @Author  : October
# @Site    : 
# @File    : lg_Info_Management.py
# @Software: PyCharm

from PyQt5.QtWidgets import QWidget, QHBoxLayout
from ui_Info_Management import Ui_InfoManagment
from lg_Modify_Password import Lg_Modify_Password


class Lg_Info_Managment(QWidget, Ui_InfoManagment):

    def __init__(self, parent=None):
        super(Lg_Info_Managment, self).__init__(parent)
        self.setupUi(self)
        self.layout = QHBoxLayout()
        self.widget.setLayout(self.layout)
        self.subwidget = Lg_Modify_Password()
        self.layout.addWidget(self.subwidget)
        # 信号与槽
        self.modifyPassword.clicked.connect(self.on_modifyPassword_Clicked)


    # 修改密码
    def on_modifyPassword_Clicked(self):
        self.layout.removeWidget(self.subwidget)
        self.subwidget.close()
        self.subwidget = Lg_Modify_Password()
        self.layout.addWidget(self.subwidget)


    # 关闭窗口
    def closeEvent(self, QCloseEvent):
        self.subwidget.close()

