#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2018/5/30 12:49
# @Author  : October
# @Site    : 
# @File    : NetLinkProcess.py
# @Software: PyCharm

from PyQt5.QtCore import QByteArray, QDataStream, QIODevice
import Constants as Const


class NetLinkProcess(object):

    # 将向服务器传输的信息封包
    @classmethod
    def Packge(cls, InfoList):
        action = '/'
        for s in InfoList:
            action = action + s + '/'
        return action


    # 将从服务器收到的消息解包
    @classmethod
    def Unpack(cls, action):
        condition = lambda t: t != ""
        InfoList = list(filter(condition, action.split('/')))
        return InfoList


    # 发送网络信息
    @classmethod
    def sendRequest(cls, socket, request):
        send = QByteArray()
        stream = QDataStream(send, QIODevice.WriteOnly)
        stream.setVersion(QDataStream.Qt_5_7)
        stream.writeUInt16(0)
        stream.writeQString(request)
        stream.device().seek(0)
        stream.writeUInt16(send.size() - Const.SIZEOF_UINT16)
        socket.write(send)


    # 服务器出错
    @classmethod
    def serverError(cls):
        print("服务器出错")


    # 连接服务器成功
    @classmethod
    def connected(cls):
        print("服务器连接成功")
