#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2018/5/27 22:12
# @Author  : October
# @Site    : 
# @File    : lg_personal.py
# @Software: PyCharm

from PyQt5.QtWidgets import QWidget, QTableWidgetItem, QMessageBox
from PyQt5.QtCore import Qt, QDataStream
from ui_Personal import Ui_Personal
from lg_Personal_Info import  Lg_Personal_Info
from lg_School_Info import Lg_School_Info
from NetLinkProcess import NetLinkProcess as NLP
import GlobalVariable as GV
import Constants as CONST


class Lg_Personal(QWidget, Ui_Personal):

    def __init__(self, parent=None):
        super(Lg_Personal, self).__init__(parent)
        self.setupUi(self)
        self.layout = self.widget.layout()
        self.school_info = Lg_School_Info()
        self.personal_info = None
        self.layout.addWidget(self.school_info)
        self.nextBlockSize = 0
        # 信号与槽
        GV.SOCKET.readyRead.connect(self.readResponse)
        self.stuInfo.clicked.connect(self.on_stuInfo_Clicked)
        self.priInfo.clicked.connect(self.on_perInfo_Clicked)
        # 初始化时请求查询学籍信息
        NLP.sendRequest(GV.SOCKET, CONST.STUDENT_INFO)


    # 请求查询学籍信息
    def on_stuInfo_Clicked(self):
        if not self.school_info is None:
            self.layout.removeWidget(self.school_info)
        else:
            self.layout.removeWidget(self.personal_info)
        self.school_info = Lg_School_Info()
        self.personal_info = None
        self.layout.addWidget(self.school_info)
        NLP.sendRequest(GV.SOCKET, CONST.STUDENT_INFO)


    # 请求查询个人信息
    def on_perInfo_Clicked(self):
        if not self.school_info is None:
            self.layout.removeWidget(self.school_info)
        else:
            self.layout.removeWidget(self.personal_info)
        self.school_info = None
        self.personal_info = Lg_Personal_Info()
        self.layout.addWidget(self.personal_info)
        NLP.sendRequest(GV.SOCKET, CONST.PERSONAL_INFO)


    # 读取服务器响应的数据
    def readResponse(self):
        stream = QDataStream(GV.SOCKET)
        stream.setVersion(QDataStream.Qt_5_7)

        while True:
            if self.nextBlockSize == 0:
                if GV.SOCKET.bytesAvailable() < CONST.SIZEOF_UINT16:
                    break
                self.nextBlockSize = stream.readUInt16()
            if GV.SOCKET.bytesAvailable() < self.nextBlockSize:
                break
            self.nextBlockSize = 0
            response = stream.readQString()
            self.handleResponse(response)


    # 处理从服务器获得的数据
    def handleResponse(self, response):
        response = response.split('+')
        action = response.pop(0)
        # 显示学籍信息
        if action == CONST.STUDENT_INFO:
            response = NLP.Unpack(response[0])
            response = response[0].split('|')[1:-1]
            response_1 = response[:7]
            for i in range(len(response_1)):
                newItem = QTableWidgetItem(response_1[i] + "      ")
                newItem.setTextAlignment(Qt.AlignLeft | Qt.AlignVCenter)
                row = i // 2 + 1
                col = -1
                if i % 2 == 0:
                    col = 1
                else:
                    col = 3
                self.school_info.infoTable.setItem(row, col, newItem)
            response_2 = response[7:12]
            for i in range(len(response_2)):
                newItem = QTableWidgetItem(response_2[i] + "      ")
                newItem.setTextAlignment(Qt.AlignLeft | Qt.AlignVCenter)
                row = i // 2 + 6
                col = -1
                if i % 2 == 0:
                    col = 1
                else:
                    col = 3
                self.school_info.infoTable.setItem(row, col, newItem)
            response_3 = response[12:]
            for i in range(len(response_3)):
                newItem = QTableWidgetItem(response_3[i] + "      ")
                newItem.setTextAlignment(Qt.AlignLeft | Qt.AlignVCenter)
                row = i // 2 + 10
                col = -1
                if i % 2 == 0:
                    col = 1
                else:
                    col = 3
                self.school_info.infoTable.setItem(row, col, newItem)
        # 显示交互信息
        elif action == CONST.PERSONAL_INFO:
            response = NLP.Unpack(response[0])
            for i in range(len(response)):
                newItem = QTableWidgetItem(response[i])
                newItem.setTextAlignment(Qt.AlignLeft | Qt.AlignVCenter)
                self.personal_info.tableWidget.setItem(i, 1, newItem)

        elif action == CONST.FALSE:
            QMessageBox.question(self, "提示", "查询失败   ", QMessageBox.Yes, QMessageBox.Yes)

    # 关闭窗口
    def closeEvent(self, QCloseEvent):
        GV.SOCKET.readyRead.disconnect(self.readResponse)



if __name__ == '__main__':
    import sys
    from PyQt5.QtWidgets import QApplication

    app = QApplication(sys.argv)
    win = Lg_Personal()
    win.show()
    app.exec_()


