#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2018/6/4 21:04
# @Author  : October
# @Site    : 
# @File    : lg_Personal_Info.py
# @Software: PyCharm

from PyQt5.QtWidgets import QWidget
from ui_Personal_Info import Ui_Personal_Info


class Lg_Personal_Info(QWidget, Ui_Personal_Info):

    def __init__(self, parent=None):
        super(Lg_Personal_Info, self).__init__(parent)
        self.setupUi(self)




if __name__ == '__main__':
    import sys
    from PyQt5.QtWidgets import QApplication

    app  = QApplication(sys.argv)
    win = Lg_Personal_Info()
    win.show()
    app.exec_()