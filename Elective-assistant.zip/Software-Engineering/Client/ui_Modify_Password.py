# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui_Modify_Password.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_Modify_Password(object):
    def setupUi(self, Modify_Password):
        Modify_Password.setObjectName("Modify_Password")
        Modify_Password.resize(712, 453)
        Modify_Password.setFocusPolicy(QtCore.Qt.NoFocus)
        Modify_Password.setFrameShape(QtWidgets.QFrame.StyledPanel)
        Modify_Password.setFrameShadow(QtWidgets.QFrame.Raised)
        self.label_3 = QtWidgets.QLabel(Modify_Password)
        self.label_3.setGeometry(QtCore.QRect(218, 240, 72, 15))
        self.label_3.setObjectName("label_3")
        self.verifyPassword = QtWidgets.QLineEdit(Modify_Password)
        self.verifyPassword.setGeometry(QtCore.QRect(320, 230, 151, 31))
        font = QtGui.QFont()
        font.setFamily("SimSun-ExtB")
        self.verifyPassword.setFont(font)
        self.verifyPassword.setFocusPolicy(QtCore.Qt.ClickFocus)
        self.verifyPassword.setMaxLength(16)
        self.verifyPassword.setEchoMode(QtWidgets.QLineEdit.Password)
        self.verifyPassword.setObjectName("verifyPassword")
        self.label = QtWidgets.QLabel(Modify_Password)
        self.label.setGeometry(QtCore.QRect(208, 110, 91, 31))
        self.label.setObjectName("label")
        self.newPassword = QtWidgets.QLineEdit(Modify_Password)
        self.newPassword.setGeometry(QtCore.QRect(320, 170, 151, 31))
        font = QtGui.QFont()
        font.setFamily("SimSun-ExtB")
        self.newPassword.setFont(font)
        self.newPassword.setFocusPolicy(QtCore.Qt.ClickFocus)
        self.newPassword.setMaxLength(16)
        self.newPassword.setEchoMode(QtWidgets.QLineEdit.Password)
        self.newPassword.setObjectName("newPassword")
        self.label_2 = QtWidgets.QLabel(Modify_Password)
        self.label_2.setGeometry(QtCore.QRect(208, 180, 91, 16))
        self.label_2.setObjectName("label_2")
        self.oldPassword = QtWidgets.QLineEdit(Modify_Password)
        self.oldPassword.setGeometry(QtCore.QRect(320, 110, 151, 31))
        font = QtGui.QFont()
        font.setFamily("SimSun-ExtB")
        self.oldPassword.setFont(font)
        self.oldPassword.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.oldPassword.setMaxLength(16)
        self.oldPassword.setEchoMode(QtWidgets.QLineEdit.Password)
        self.oldPassword.setObjectName("oldPassword")
        self.affirm = QtWidgets.QPushButton(Modify_Password)
        self.affirm.setGeometry(QtCore.QRect(300, 290, 93, 28))
        self.affirm.setObjectName("affirm")

        self.retranslateUi(Modify_Password)
        QtCore.QMetaObject.connectSlotsByName(Modify_Password)

    def retranslateUi(self, Modify_Password):
        _translate = QtCore.QCoreApplication.translate
        Modify_Password.setWindowTitle(_translate("Modify_Password", "Frame"))
        self.label_3.setText(_translate("Modify_Password", "确认密码："))
        self.label.setText(_translate("Modify_Password", "输入旧密码："))
        self.label_2.setText(_translate("Modify_Password", "输入新密码："))
        self.affirm.setText(_translate("Modify_Password", "确认"))

