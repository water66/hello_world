# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui_Login.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_LOGIN(object):
    def setupUi(self, LOGIN):
        LOGIN.setObjectName("LOGIN")
        LOGIN.resize(400, 270)
        LOGIN.setMinimumSize(QtCore.QSize(400, 270))
        LOGIN.setMaximumSize(QtCore.QSize(400, 270))
        self.forget = QtWidgets.QPushButton(LOGIN)
        self.forget.setGeometry(QtCore.QRect(298, 120, 71, 28))
        font = QtGui.QFont()
        font.setPointSize(9)
        font.setUnderline(True)
        self.forget.setFont(font)
        self.forget.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.forget.setToolTip("")
        self.forget.setCheckable(False)
        self.forget.setFlat(True)
        self.forget.setObjectName("forget")
        self.account = QtWidgets.QLineEdit(LOGIN)
        self.account.setGeometry(QtCore.QRect(68, 50, 211, 30))
        font = QtGui.QFont()
        font.setFamily("SimSun-ExtB")
        font.setPointSize(11)
        self.account.setFont(font)
        self.account.setText("")
        self.account.setMaxLength(20)
        self.account.setObjectName("account")
        self.password = QtWidgets.QLineEdit(LOGIN)
        self.password.setGeometry(QtCore.QRect(68, 120, 211, 30))
        font = QtGui.QFont()
        font.setFamily("SimSun-ExtB")
        font.setPointSize(11)
        self.password.setFont(font)
        self.password.setFocusPolicy(QtCore.Qt.ClickFocus)
        self.password.setContextMenuPolicy(QtCore.Qt.NoContextMenu)
        self.password.setMaxLength(15)
        self.password.setEchoMode(QtWidgets.QLineEdit.Password)
        self.password.setObjectName("password")
        self.login = QtWidgets.QPushButton(LOGIN)
        self.login.setGeometry(QtCore.QRect(80, 200, 190, 30))
        self.login.setFocusPolicy(QtCore.Qt.ClickFocus)
        self.login.setObjectName("login")

        self.retranslateUi(LOGIN)
        QtCore.QMetaObject.connectSlotsByName(LOGIN)

    def retranslateUi(self, LOGIN):
        _translate = QtCore.QCoreApplication.translate
        LOGIN.setWindowTitle(_translate("LOGIN", "登录"))
        self.forget.setText(_translate("LOGIN", "忘记密码"))
        self.account.setPlaceholderText(_translate("LOGIN", "学号/工号"))
        self.password.setToolTip(_translate("LOGIN", "<html><head/><body><p><span style=\" font-size:9pt;\">学生初始密码为身份证后6位</span></p></body></html>"))
        self.password.setWhatsThis(_translate("LOGIN", "<html><head/><body><p><br/></p></body></html>"))
        self.password.setPlaceholderText(_translate("LOGIN", "密码"))
        self.login.setText(_translate("LOGIN", "登录"))

