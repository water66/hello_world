#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2018/5/27 15:22
# @Author  : October
# @Site    : 
# @File    : lg_MainWindow.py
# @Software: PyCharm

import sys
from PyQt5.QtWidgets import QWidget, QHBoxLayout, QMessageBox
from ui_MainWindow import Ui_MainWindow
import GlobalVariable as GV


class Lg_MainWindow(QWidget, Ui_MainWindow):

    def __init__(self, parent=None):
        super(Lg_MainWindow, self).__init__(parent)
        self.setupUi(self)
        self.layout = QHBoxLayout()
        self.widget.setLayout(self.layout)
        self.goback.setEnabled(False)


    # 更新界面
    def updateUI(self, widget):
        self.layout.removeWidget(self.layout.widget())
        self.layout.addWidget(widget)


    # 退出程序
    def closeEvent(self, QCloseEvent):
        reply = QMessageBox.question(self, "提示", "确定退出？", QMessageBox.Ok | QMessageBox.Cancel, QMessageBox.Ok)
        if reply == QMessageBox.Ok:
            if not GV.WIN_LOGIN is None:
                GV.WIN_LOGIN.close()
            QCloseEvent.accept()
        elif reply == QMessageBox.Cancel:
            QCloseEvent.ignore()




if __name__ == '__main__':
    import sys
    from PyQt5.QtWidgets import QApplication

    app = QApplication(sys.argv)

    GV.WIN_MAIN = Lg_MainWindow()
    GV.WIN_MAIN.show()

    app.exit(app.exec_())
