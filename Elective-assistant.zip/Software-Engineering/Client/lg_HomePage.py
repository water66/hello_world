#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2018/5/27 16:06
# @Author  : October
# @Site    : 
# @File    : lg_HomePage.py
# @Software: PyCharm

from PyQt5.QtWidgets import QWidget
from ui_HomePage import Ui_HomePage


class Lg_HomePage(QWidget, Ui_HomePage):

    def __init__(self, parent=None):
        super(Lg_HomePage, self).__init__(parent)
        self.setupUi(self)