#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2018/6/14 10:22
# @Author  : October
# @Site    : 
# @File    : lg_Bind_Email.py
# @Software: PyCharm

from PyQt5.QtWidgets import QWidget, QMessageBox
from PyQt5.QtCore import QDataStream
from ui_Bind_Email import Ui_Bind
from NetLinkProcess import NetLinkProcess as NLP
import GlobalVariable as GV
import Constants as CONST


class Lg_Bind(QWidget, Ui_Bind):

    def __init__(self, parent=None):
        super(Lg_Bind, self).__init__(parent)
        self.setupUi(self)
        self.nextBlockSize = 0
        # 绑定信号与槽
        GV.SOCKET.readyRead.connect(self.readResponse)
        self.affirm.clicked.connect(self.on_affirm_Clicked)     # 点击确认
        self.getVf.clicked.connect(self.on_getVf_Clicked)       # 获取验证码


    # 确认
    def on_affirm_Clicked(self):
        _input_email = self.email.text()
        _vf = self.verifiaction.text()

        if _input_email == '':
            QMessageBox.question(self, "提示", "邮箱不能为空   ", QMessageBox.Yes, QMessageBox.Yes)
            return
        elif _vf == '':
            QMessageBox.question(self, "提示", "验证码不能为空   ", QMessageBox.Yes, QMessageBox.Yes)
            return
        request = NLP.Packge([CONST.BIND, _input_email, _vf])
        NLP.sendRequest(GV.SOCKET, request)


    # 获取验证码
    def on_getVf_Clicked(self):
        input_email = self.email.text()
        if input_email == '':
            QMessageBox.question(self, "提示", "请输入邮箱地址   ", QMessageBox.Yes, QMessageBox.Yes)
            return
        else:
            request = NLP.Packge([CONST.BIND_GET_VF, input_email])
            NLP.sendRequest(GV.SOCKET, request)


    # 读取服务器返回的数据并做处理
    def readResponse(self):
        stream = QDataStream(GV.SOCKET)
        stream.setVersion(QDataStream.Qt_5_7)

        while True:
            if self.nextBlockSize == 0:
                if GV.SOCKET.bytesAvailable() < CONST.SIZEOF_UINT16:
                    break
                self.nextBlockSize = stream.readUInt16()
            if GV.SOCKET.bytesAvailable() < self.nextBlockSize:
                break
            self.nextBlockSize = 0
            response = stream.readQString()
            self.handleResponse(response)


    # 处理响应
    def handleResponse(self, response):
        response = response.split('+')
        action = response.pop(0)

        if action == CONST.TRUE:
            if response[0] == CONST.BIND_GET_VF:
                QMessageBox.question(self, "提示", "验证码发送成功   ", QMessageBox.Yes, QMessageBox.Yes)
            elif response[0] == CONST.BIND:
                QMessageBox.question(self, "提示", "邮箱绑定成功   ", QMessageBox.Yes, QMessageBox.Yes)
                GV.WIN_MAIN.show()
                self.close()
        elif action == CONST.FALSE:
            if response[0] == CONST.BIND_GET_VF:
                QMessageBox.question(self, "提示", "验证码发送失败，请检查邮箱地址   ", QMessageBox.Yes, QMessageBox.Yes)
            elif response[0] == CONST.BIND:
                QMessageBox.question(self, "提示", "邮箱绑定失败   ", QMessageBox.Yes, QMessageBox.Yes)


    # 关闭窗口
    def closeEvent(self, QCloseEvent):
        GV.SOCKET.readyRead.disconnect(self.readResponse)



if __name__ == '__main__':
    import sys
    from PyQt5.QtWidgets import QApplication
    app = QApplication(sys.argv)
    window = Lg_Bind()
    window.show()
    app.exit(app.exec_())

