#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2018/6/5 19:07
# @Author  : October
# @Site    : 
# @File    : lg_Modify_Password.py
# @Software: PyCharm

from PyQt5.QtWidgets import QFrame, QMessageBox
from PyQt5.QtCore import QDataStream
from ui_Modify_Password import Ui_Modify_Password
from NetLinkProcess import NetLinkProcess as NLP
import GlobalVariable as GV
import Constants as CONST


class Lg_Modify_Password(QFrame, Ui_Modify_Password):

    def __init__(self, parent=None):
        super(Lg_Modify_Password, self).__init__(parent)
        self.setupUi(self)
        self.nextBlockSize = 0
        self.OldPwd = None
        self.NewPwd = None
        self.Verification = None
        # 信号与槽
        GV.SOCKET.readyRead.connect(self.readResponse)
        self.affirm.clicked.connect(self.on_affirm_Clicked)


    # 确认
    def on_affirm_Clicked(self):
        self.OldPwd = self.oldPassword.text()
        self.NewPwd = self.newPassword.text()
        self.Verification = self.verifyPassword.text()
        # 两次输入的新密码不匹配
        if not self.Verification == self.NewPwd:
            QMessageBox.question(self, "提示", "两次输入的新密码不一致   ", QMessageBox.Yes, QMessageBox.Yes)
            return
        # 新旧密码不能相同
        if self.OldPwd == self.NewPwd:
            QMessageBox.question(self, "提示", "新旧密码不能相同   ", QMessageBox.Yes, QMessageBox.Yes)
            return
        # 向服务器确认
        request = [CONST.MODIFY_PASSWORD, self.OldPwd, self.NewPwd]
        request = NLP.Packge(request)
        NLP.sendRequest(GV.SOCKET, request)


    # 读取服务器响应的数据
    def readResponse(self):
        stream = QDataStream(GV.SOCKET)
        stream.setVersion(QDataStream.Qt_5_7)

        while True:
            if self.nextBlockSize == 0:
                if GV.SOCKET.bytesAvailable() < CONST.SIZEOF_UINT16:
                    break
                self.nextBlockSize = stream.readUInt16()
            if GV.SOCKET.bytesAvailable() < self.nextBlockSize:
                break
            self.nextBlockSize = 0
            response = stream.readQString()
            self.handleResponse(response)


    # 处理消息
    def handleResponse(self, response):
        response = response.split('+')
        action = response.pop(0)
        # 修改密码失败
        if action == CONST.TRUE and response[0] == CONST.MODIFY_PASSWORD:
            QMessageBox.question(self, "提示", "密码修改成功   ", QMessageBox.Yes, QMessageBox.Yes)
        # 修改密码成功
        elif action == CONST.FALSE and response[0] == CONST.MODIFY_PASSWORD:
            QMessageBox.question(self, "提示", "密码修改失败，请检查   ", QMessageBox.Yes, QMessageBox.Yes)


    # 关闭窗口
    def closeEvent(self, QCloseEvent):
        GV.SOCKET.readyRead.disconnect(self.readResponse)