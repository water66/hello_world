#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2018/5/30 13:20
# @Author  : October
# @Site    : 
# @File    : lg_T_HomePage.py
# @Software: PyCharm

from PyQt5.QtWidgets import QWidget
from ui_T_HomePage import Ui_T_HomePage

class Lg_T_HomePage(QWidget, Ui_T_HomePage):

    def __init__(self, parent=None):
        super(Lg_T_HomePage, self).__init__(parent)
        self.setupUi(self)