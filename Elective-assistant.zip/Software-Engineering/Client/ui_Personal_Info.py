# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui_Personal_Info.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_Personal_Info(object):
    def setupUi(self, Personal_Info):
        Personal_Info.setObjectName("Personal_Info")
        Personal_Info.resize(400, 300)
        self.horizontalLayout = QtWidgets.QHBoxLayout(Personal_Info)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.tableWidget = QtWidgets.QTableWidget(Personal_Info)
        self.tableWidget.setObjectName("tableWidget")
        self.tableWidget.setColumnCount(2)
        self.tableWidget.setRowCount(5)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(0, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(1, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(2, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(3, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(4, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(0, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(1, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(0, 0, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(1, 0, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(2, 0, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(3, 0, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(4, 0, item)
        self.tableWidget.horizontalHeader().setVisible(False)
        self.tableWidget.verticalHeader().setVisible(False)
        self.horizontalLayout.addWidget(self.tableWidget)
        self.tableWidget.horizontalHeader().setStretchLastSection(True)  # 最后一列填充满表格

        self.retranslateUi(Personal_Info)
        QtCore.QMetaObject.connectSlotsByName(Personal_Info)

    def retranslateUi(self, Personal_Info):
        _translate = QtCore.QCoreApplication.translate
        Personal_Info.setWindowTitle(_translate("Personal_Info", "Form"))
        item = self.tableWidget.verticalHeaderItem(0)
        item.setText(_translate("Personal_Info", "新建行"))
        item = self.tableWidget.verticalHeaderItem(1)
        item.setText(_translate("Personal_Info", "学号："))
        item = self.tableWidget.verticalHeaderItem(2)
        item.setText(_translate("Personal_Info", "姓名："))
        item = self.tableWidget.verticalHeaderItem(3)
        item.setText(_translate("Personal_Info", "性别："))
        item = self.tableWidget.verticalHeaderItem(4)
        item.setText(_translate("Personal_Info", "生日："))
        __sortingEnabled = self.tableWidget.isSortingEnabled()
        self.tableWidget.setSortingEnabled(False)
        item = self.tableWidget.item(0, 0)
        item.setText(_translate("Personal_Info", "学号："))
        item = self.tableWidget.item(1, 0)
        item.setText(_translate("Personal_Info", "姓名："))
        item = self.tableWidget.item(2, 0)
        item.setText(_translate("Personal_Info", "性别："))
        item = self.tableWidget.item(3, 0)
        item.setText(_translate("Personal_Info", "生日："))
        item = self.tableWidget.item(4, 0)
        item.setText(_translate("Personal_Info", "邮箱："))
        self.tableWidget.setSortingEnabled(__sortingEnabled)

