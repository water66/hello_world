#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2018/5/21 18:05
# @Author  : October
# @Site    : 
# @File    : lg_Login.py
# @Software: PyCharm

from PyQt5.QtWidgets import QWidget, QMessageBox
from PyQt5.QtCore import QDataStream, pyqtSignal
from ui_Login import Ui_LOGIN
from NetLinkProcess import NetLinkProcess as NLP
import GlobalVariable as GV
import Constants as CONST


class Lg_Login(QWidget, Ui_LOGIN):
    loginSuccessfully = pyqtSignal(str)

    def __init__(self, parent=None):
        super(Lg_Login, self).__init__(parent)
        self.nextBlockSize = 0
        self.setupUi(self)
        # 绑定信号与槽
        GV.SOCKET.readyRead.connect(self.readResponse)
        self.login.clicked.connect(self.on_login_Clicked)


    # 登录
    def on_login_Clicked(self):
        account = self.account.text()
        password = self.password.text()
        if account == '' or password == '':
            QMessageBox.question(self, "提示", "请输入正确的用户名和密码   ", QMessageBox.Yes, QMessageBox.Yes)
            return
        InfoList = [CONST.LOGIN, account, password]
        NLP.sendRequest(GV.SOCKET, NLP.Packge(InfoList))


    # 读取服务器返回的数据并做处理
    def readResponse(self):
        stream = QDataStream(GV.SOCKET)
        stream.setVersion(QDataStream.Qt_5_7)

        while True:
            if self.nextBlockSize == 0:
                if GV.SOCKET.bytesAvailable() < CONST.SIZEOF_UINT16:
                    break
                self.nextBlockSize = stream.readUInt16()
            if GV.SOCKET.bytesAvailable() < self.nextBlockSize:
                break
            self.nextBlockSize = 0
            response = stream.readQString()
            response = NLP.Unpack(response)

            if response[0] == CONST.TRUE:
                GV.TYPE = response[1]
                print("登录成功")
                self.loginSuccessfully.emit(response[2])
            elif response[0] == CONST.FALSE:
                print("登录失败")
                self.loginFailed()


    # 登录失败
    def loginFailed(self):
        QMessageBox.question(self, "提示", "登录失败   ", QMessageBox.Yes, QMessageBox.Yes)


    # 关闭窗口
    def closeEvent(self, QCloseEvent):
        GV.SOCKET.readyRead.disconnect(self.readResponse)




if __name__ == '__main__':
    import sys
    from PyQt5.QtWidgets import QApplication

    app = QApplication(sys.argv)

    GV.SOCKET.connectToHost(CONST.ADDR, CONST.PORT)
    GV.SOCKET.connected.connect(NLP.connected)  # 连接到服务器
    GV.SOCKET.error.connect(NLP.serverError)  # 服务器出错
    GV.SOCKET.disconnected.connect(GV.SOCKET.deleteLater)

    GV.WIN_LOGIN = Lg_Login()
    GV.WIN_LOGIN.show()

    app.exec_()
