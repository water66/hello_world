import sys
from PyQt5.QtNetwork import QHostAddress, QTcpServer
from PyQt5.QtWidgets import QApplication

from ChildSocket import ChildSocket
import Constants as CONST


class TcpServer(QTcpServer):

    def __init__(self, parent=None):
        super(TcpServer, self).__init__(parent)

    def incomingConnection(self, socketId):
        socket = ChildSocket(self)
        socket.setSocketDescriptor(socketId)
        print("建立新链接:", socket.peerAddress().toString())


if __name__ == '__main__':

    app = QApplication(sys.argv)

    Server = TcpServer()
    if not Server.listen(QHostAddress(CONST.HOST), CONST.PORT):
        print("服务器监听失败！\n")
    else:
        print("等待连接...")

    app.exec_()
