"""
    读取数据库信息并处理

"""


class AccessDatabase:

    # 处理登录请求
    @classmethod
    def login(cls, Database, Id, Password):
        try:
            cursor = Database.cursor()
            cursor.execute(
                "SELECT * FROM account WHERE id=? AND password=?", (Id, Password,))
            result = cursor.fetchall()
            cursor.execute(
                "SELECT mail FROM person_information WHERE id=?", (Id,))
            _email = cursor.fetchall()
            cursor.close()
        except Exception:
            return False, None, None
        else:
            _email = _email[0][0]
            if len(result) == 1:
                result = list(result[0])
                if _email is None:
                    return True, result[2], False
                else:
                    return True, result[2], True
            else:
                return False, None, None

    # 查询可选课程
    @classmethod
    def getCoursesInfo(cls, Database):
        try:
            cursor = Database.cursor()
            cursor.execute("SELECT * FROM course_information")
            course = cursor.fetchall()
            cursor.execute("SELECT * FROM course_schedule")
            schedule = cursor.fetchall()
            cursor.close()
        except Exception:
            return False, False
        else:
            CourseResult = []
            for c in course:
                str = ""
                for item in c:
                    str = str + '|' + item
                CourseResult.append(str)
            ScheduleResult = []
            for s in schedule:
                str = ""
                for item in s:
                    str = str + '|' + item
                ScheduleResult.append(str)
            return CourseResult, ScheduleResult

    # 写入选课信息
    @classmethod
    def writeCourseSelectInfo(cls, Id, Database, Information):
        try:
            cursor = Database.cursor()
            for info in Information:
                cursor.execute(
                    "SELECT * FROM grade WHERE id=? AND cno=?", (Id, info,))
                if not len(cursor.fetchall()) == 0:
                    raise Exception("不能重复选课!")
                cursor.execute(
                    "INSERT INTO grade(id, cno) VALUES(?, ?)", (Id, info,))
            cursor.close()
            Database.commit()
        except Exception:
            Database.rollback()
            return False
        else:
            return True

    # 读取已选课程信息
    @classmethod
    def readCourseSelectInfo(cls, Id, Database):
        try:
            cursor = Database.cursor()
            cursor.execute("SELECT cno FROM grade WHERE id=?", (Id,))
            result = cursor.fetchall()
            if len(result) == 0:
                return [], []
            cnos = []
            for each in result:
                cnos.append(each[0])
            course = []
            schedule = []
            for cno in cnos:
                cursor.execute(
                    "SELECT * FROM course_information WHERE cno=?", (cno,))
                result = cursor.fetchall()
                if not len(result) == 0:
                    course.append(result[0])
                cursor.execute(
                    "SELECT * FROM course_schedule WHERE cno=?", (cno,))
                result = cursor.fetchall()
                if not len(result) == 0:
                    schedule.append(result[0])
            cursor.close()
        except Exception:
            return False, False
        else:
            CourseResult = []
            for c in course:
                str = ""
                for item in c:
                    str = str + '|' + item
                CourseResult.append(str)
            ScheduleResult = []
            for s in schedule:
                str = ""
                for item in s:
                    str = str + '|' + item
                ScheduleResult.append(str)
            return CourseResult, ScheduleResult

    # 退课
    @classmethod
    def quitCourse(cls, Id, Database, Information):
        try:
            cursor = Database.cursor()
            for cno in Information:
                cursor.execute(
                    "DELETE FROM grade WHERE id=? AND cno=?", (Id, cno,))
            cursor.close()
            Database.commit()
        except Exception:
            Database.rollback()
            return False
        else:
            return True

    # 查询所有成绩
    @classmethod
    def selectAllGrade(cls, Id, Database):
        try:
            cursor = Database.cursor()
            cursor.execute("SELECT * FROM grade WHERE id=?", (Id,))
            grade = cursor.fetchall()
            course = []
            for each in grade:
                cursor.execute(
                    "SELECT * FROM course_information WHERE cno=?", (each[1],))
                cou = cursor.fetchall()
                course.append(cou[0])
        except Exception:
            return False, False
        else:
            GradeResult = []
            for g in grade:
                s = ""
                for item in g:
                    item = str(item)
                    s = s + '|' + item
                GradeResult.append(s)
            CourseResult = []
            for c in course:
                s = ""
                for item in c:
                    s = s + '|' + item
                CourseResult.append(s)
            return GradeResult, CourseResult

    # 查询及格成绩
    @classmethod
    def selectPassGrade(cls, Id, Database):
        try:
            cursor = Database.cursor()
            cursor.execute(
                "SELECT * FROM grade WHERE id=? AND score>=?", (Id, 60.0, ))
            grade = cursor.fetchall()
            course = []
            for each in grade:
                cursor.execute(
                    "SELECT * FROM course_information WHERE cno=?", (each[1],))
                cou = cursor.fetchall()
                course.append(cou[0])
        except Exception:
            return False, False
        else:
            GradeResult = []
            for g in grade:
                s = ""
                for item in g:
                    item = str(item)
                    s = s + '|' + item
                GradeResult.append(s)
            CourseResult = []
            for c in course:
                s = ""
                for item in c:
                    s = s + '|' + item
                CourseResult.append(s)
            return GradeResult, CourseResult

    # 查询不及格成绩
    @classmethod
    def selectFailGrade(cls, Id, Database):
        try:
            cursor = Database.cursor()
            cursor.execute(
                "SELECT * FROM grade WHERE id=? AND score<?", (Id, 60.0, ))
            grade = cursor.fetchall()
            course = []
            for each in grade:
                cursor.execute(
                    "SELECT * FROM course_information WHERE cno=?", (each[1],))
                cou = cursor.fetchall()
                course.append(cou[0])
        except Exception:
            return False, False
        else:
            GradeResult = []
            for g in grade:
                s = ""
                for item in g:
                    item = str(item)
                    s = s + '|' + item
                GradeResult.append(s)
            CourseResult = []
            for c in course:
                s = ""
                for item in c:
                    s = s + '|' + item
                CourseResult.append(s)
            return GradeResult, CourseResult

    # 查询完整课表
    @classmethod
    def getWholeSchedule(cls, Id, Database):
        try:
            cursor = Database.cursor()
            cursor.execute("SELECT cno FROM grade WHERE id=?", (Id, ))
            allCnos = cursor.fetchall()
            allCnames = []
            for cno in allCnos:
                cursor.execute(
                    "SELECT * FROM course_information WHERE cno=?", cno)
                result = cursor.fetchall()
                allCnames.append(result[0])
            allSchedules = []
            for cno in allCnos:
                cursor.execute(
                    "SELECT * FROM course_schedule WHERE cno=?", cno)
                result = cursor.fetchall()
                for each in result:
                    allSchedules.append(each)
        except Exception:
            return False
        else:
            allCourses = []
            for cno in allCnos:
                info = None
                for cname in allCnames:
                    if cno[0] == cname[0]:
                        info = '|' + cno[0] + '|' + cname[1]
                for schedule in allSchedules:
                    if cno[0] == schedule[0]:
                        copy_info = info
                        for each in schedule[1:]:
                            copy_info = copy_info + '|' + each
                        allCourses.append(copy_info)
            return allCourses

    # 查询学籍信息
    @classmethod
    def getSchoolInfo(cls, Id, Database):
        try:
            cursor = Database.cursor()
            cursor.execute("SELECT * FROM school_roll WHERE id=?", (Id, ))
        except Exception:
            return False
        else:
            result = cursor.fetchall()
            SchoolInfo = []
            info = '|'
            for each in result:
                for item in each:
                    each = str(each)
                    info = info + item + '|'
                SchoolInfo.append(info)
            return SchoolInfo

    # 查询个人信息
    @classmethod
    def getPersonalInfo(cls, Id, Database):
        try:
            cursor = Database.cursor()
            cursor.execute("SELECT * FROM school_roll WHERE id=?", (Id, ))
            result = cursor.fetchall()
            cursor.execute(
                "SELECT mail FROM person_information WHERE id=?", (Id, ))
            email = cursor.fetchall()
        except Exception:
            return False
        else:
            PersonalInfo = []
            PersonalInfo.append(result[0][0])
            PersonalInfo.append(result[0][1])
            PersonalInfo.append(result[0][2])
            PersonalInfo.append(result[0][5])
            PersonalInfo.append(email[0][0])
            return PersonalInfo

    # 修改密码
    @classmethod
    def modifyPassword(cls, Id, Database, RequestList):
        OldPwd = RequestList[0]
        NewPwd = RequestList[1]
        cursor = Database.cursor()
        cursor.execute("SELECT password FROM account WHERE id=?", (Id, ))
        result = cursor.fetchall()
        result = result[0][0]
        if result == OldPwd:
            cursor.execute(
                "UPDATE account SET password=? WHERE id=?", (NewPwd, Id, ))
            Database.commit()
            return True
        else:
            return False

    # 获取邮箱地址
    @classmethod
    def getEmail(cls, Id, Database):
        try:
            cursor = Database.cursor()
            cursor.execute(
                "SELECT mail FROM person_information WHERE id=?", (Id, ))
            email = cursor.fetchall()[0][0]
        except Exception:
            return False
        else:
            return email

    # 添加邮箱
    @classmethod
    def addEmail(cls, Id, Database, Email):
        try:
            cursor = Database.cursor()
            cursor.execute(
                "UPDATE person_information SET mail=? WHERE id=?", (Email, Id, ))
            Database.commit()
        except Exception:
            return False
        else:
            return True

    # 通过邮箱验证修改密码
    @classmethod
    def modifyPasswordByEmail(cls, Id, Database, Password):
        try:
            cursor = Database.cursor()
            cursor.execute(
                "UPDATE account SET password=? WHERE id=?", (Password, Id, ))
            Database.commit()
        except Exception:
            return False
        else:
            return True
