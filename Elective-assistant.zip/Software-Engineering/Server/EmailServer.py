import smtplib
from email.mime.text import MIMEText
from email.header import Header
import random


class Verification:

    # 产生验证码
    @classmethod
    def geneVerif(cls):
        verification = random.randint(10000, 99999)
        return str(verification)

    # 发送验证码
    @classmethod
    def sendmail(cls, receiver, verification):
        smtphost = 'smtp.163.com'
        port = 465
        user = '18292858317@163.com'
        pwd = 'python123456'

        # 主题 和 内容
        subject = '验证信息'
        content = "验证信息  " + verification

        msg = MIMEText(content, 'plain', )
        msg['from'] = Header(user)
        msg['to'] = Header(receiver)
        msg['subject'] = Header(subject)
        try:
            smtpObj = smtplib.SMTP_SSL(smtphost, port)
            smtpObj.login(user, pwd)
            smtpObj.sendmail(user, receiver, msg.as_string())
            return True
        except Exception:
            return False
