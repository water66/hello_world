
"""
    获取客户端的请求，
    解包请求数据，
    向客户端发送响应数据，
    封包响应数据

"""

from PyQt5.QtCore import QByteArray, QDataStream, QIODevice
import Constants as CONST


class NetLinkProcess:

    # 向客户端发送数据
    @classmethod
    def sendResponse(cls, socket, response):
        send = QByteArray()
        stream = QDataStream(send, QIODevice.WriteOnly)
        stream.setVersion(QDataStream.Qt_5_7)
        stream.writeUInt16(0)
        stream.writeQString(response)
        stream.device().seek(0)
        stream.writeUInt16(send.size() - CONST.SIZEOF_UINT16)
        socket.write(send)

    # 将服务器要发送的消息封包
    @classmethod
    def Packge(cls, responseList):
        response = '/'
        for str in responseList:
            response = response + str + '/'
        return response

    # 将服务器收到的消息解包
    @classmethod
    def Unpack(cls, request):
        condition = lambda t: t != ""
        requestList = list(filter(condition, request.split('/')))
        return requestList
