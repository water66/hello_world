
"""
    定义常量

"""


# 数据库文件路径
DB_ADDR = "./COURSE.db"

# 服务器地址
HOST = "0.0.0.0"

# 服务器监听端口号
PORT = 20000

# 网络消息前 SIZEOF_UINT16 位存储该消息的长度
SIZEOF_UINT16 = 2

# 请求成功
TRUE = "__true__"

# 请求失败
FALSE = "__false__"

# 教工帐号
F = "F"

# 学生账号
S = "S"

# 登录请求
LOGIN = "__login__"

# 请求查询可选课程信息
SELECT = "__select__"

# 选课请求
SELECT_COURSE = "__select_course__"

# 退课请求
QUIT_COURSE = "__quit_course__"

# 查询已选课程
SELECTED_COURSE = "__selected_course__"

# 查询所有课程成绩
GRADE = "__grade__"

# 查询及格课程成绩
PASS = "__pass__"

# 查询不及格成绩
FAIL = "__fail__"

# 查询完整课表
WHOLE = "__whole__"

# 查询学籍信息
STUDENT_INFO = "__student_info__"

# 查询个人信息
PERSONAL_INFO = "__personal_info__"

# 修改密码
MODIFY_PASSWORD = "__modify_password__"

# 获取验证码
GET_VERIFICATION = "__get_verification__"

# 绑定邮箱获取验证码
BIND_GET_VF = "__bind_get_vf__"

# 绑定邮箱
BIND = "__bind__"

# 忘记密码获取验证码
FORGET_GET_VF = "__forget_get_vf__"

# 忘记密码
FORGET_PASSWORD = "__forget_password__"
