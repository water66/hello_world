import sqlite3
from PyQt5.QtNetwork import QTcpSocket
from PyQt5.QtCore import QDataStream
from NetLinkProcess import NetLinkProcess as NLP
from AccessDatabase import AccessDatabase as AD
from EmailServer import Verification as VF
import Constants as CONST


class ChildSocket(QTcpSocket):

    def __init__(self, parent=None):
        super(ChildSocket, self).__init__(parent)
        self.Db_Conn = sqlite3.connect(CONST.DB_ADDR)
        self.nextBlockSize = 0
        self.id = None  # 用户账号
        self.verif = None   # 验证码
        self.bind_email = None
        # 连接信号与槽
        self.readyRead.connect(self.readRequest)
        self.disconnected.connect(self.deleteLater)
        self.disconnected.connect(self.connClosed)

    # 读取来自客户端的数据
    def readRequest(self):
        stream = QDataStream(self)
        stream.setVersion(QDataStream.Qt_5_7)
        if self.nextBlockSize == 0:
            if self.bytesAvailable() < CONST.SIZEOF_UINT16:
                return
            self.nextBlockSize = stream.readUInt16()
        if self.bytesAvailable() < self.nextBlockSize:
            return
        self.nextBlockSize = 0
        request = stream.readQString()
        # 处理请求
        self.handleRequest(request)

    # 处理请求
    def handleRequest(self, request):
        requestList = NLP.Unpack(request)
        action = requestList.pop(0)

        # 处理登录请求
        if action == CONST.LOGIN:
            self.id = requestList.pop(0)
            print("用户", self.id, "请求登录")
            consequence, accountType, _email = AD.login(
                self.Db_Conn, self.id, requestList[0])
            if consequence and _email:
                response = NLP.Packge([CONST.TRUE, accountType, CONST.TRUE])
                print("用户", self.id, "登录成功")
            elif consequence and not _email:
                response = NLP.Packge([CONST.TRUE, accountType, CONST.FALSE])
                print("用户", self.id, "登录成功")
            else:
                response = CONST.FALSE
            NLP.sendResponse(self, response)

        # 向客户端发送可选课程的信息
        if action == CONST.SELECT:
            print("用户", self.id, "请求查询课程信息")
            course, schedule = AD.getCoursesInfo(self.Db_Conn)
            response = None
            if not course or not schedule:      # 访问数据库失败
                response = CONST.FALSE + '+' + CONST.SELECT
            else:
                course = NLP.Packge(course)
                schedule = NLP.Packge(schedule)
                response = CONST.SELECT + '+' + course + '+' + schedule
            NLP.sendResponse(self, response)

        # 写入选课信息
        if action == CONST.SELECT_COURSE:
            print("用户", self.id, "请求选课")
            result = AD.writeCourseSelectInfo(
                self.id, self.Db_Conn, requestList)
            response = None
            if not result:  # 访问数据库失败
                response = CONST.FALSE + '+' + CONST.SELECT_COURSE
            else:
                response = CONST.TRUE + '+' + CONST.SELECT_COURSE
                print("用户", self.id, "选课成功")
            NLP.sendResponse(self, response)

        # 读取该账户已选课程信息并发回客户端
        if action == CONST.SELECTED_COURSE:
            print("用户", self.id, "请求查询已选课程")
            course, schedule = AD.readCourseSelectInfo(self.id, self.Db_Conn)
            response = None
            if course is False or schedule is False:
                response = CONST.FALSE + '+' + CONST.SELECTED_COURSE
            else:
                course = NLP.Packge(course)
                schedule = NLP.Packge(schedule)
                response = CONST.SELECTED_COURSE + '+' + course + '+' + schedule
            NLP.sendResponse(self, response)

        # 处理退课请求
        if action == CONST.QUIT_COURSE:
            print("用户", self.id, "请求退课")
            result = AD.quitCourse(self.id, self.Db_Conn, requestList)
            response = None
            if not result:
                response = CONST.FALSE + '+' + CONST.QUIT_COURSE
            else:
                response = CONST.TRUE + '+' + CONST.QUIT_COURSE
                print("用户", self.id, "退课成功")
            NLP.sendResponse(self, response)

        # 查询所有成绩
        if action == CONST.GRADE:
            print("用户", self.id, "请求查询成绩")
            grade, course = AD.selectAllGrade(self.id, self.Db_Conn)
            response = None
            if grade is False or course is False:
                response = CONST.FALSE + '+' + CONST.GRADE
            else:
                grade = NLP.Packge(grade)
                course = NLP.Packge(course)
                response = CONST.GRADE + '+' + grade + '+' + course
            NLP.sendResponse(self, response)

        # 查询及格成绩
        if action == CONST.PASS:
            print("用户", self.id, "请求查询及格成绩")
            grade, course = AD.selectPassGrade(self.id, self.Db_Conn)
            response = None
            if grade is False or course is False:
                response = CONST.FALSE + '+' + CONST.PASS
            else:
                grade = NLP.Packge(grade)
                course = NLP.Packge(course)
                response = CONST.PASS + '+' + grade + '+' + course
            NLP.sendResponse(self, response)

        # 查询不及格成绩
        if action == CONST.FAIL:
            print("用户", self.id, "请求查询不及格成绩")
            grade, course = AD.selectFailGrade(self.id, self.Db_Conn)
            response = None
            if grade is False or course is False:
                response = CONST.FALSE + '+' + CONST.FAIL
            else:
                grade = NLP.Packge(grade)
                course = NLP.Packge(course)
                response = CONST.FAIL + '+' + grade + '+' + course
            NLP.sendResponse(self, response)

        # 查询完整课表
        if action == CONST.WHOLE:
            print("用户", self.id, "请求查询完整课表")
            allCourses = AD.getWholeSchedule(self.id, self.Db_Conn)
            response = None
            if allCourses is False:
                response = CONST.FALSE + '+' + CONST.WHOLE
            else:
                allCourses = NLP.Packge(allCourses)
                response = CONST.WHOLE + '+' + allCourses
            NLP.sendResponse(self, response)

        # 查询学籍信息
        if action == CONST.STUDENT_INFO:
            print("用户", self.id, "请求查询学籍信息")
            SchoolInfo = AD.getSchoolInfo(self.id, self.Db_Conn)
            response = None
            if SchoolInfo is False:
                response = CONST.FALSE + '+' + CONST.STUDENT_INFO
            else:
                SchoolInfo = NLP.Packge(SchoolInfo)
                response = CONST.STUDENT_INFO + '+' + SchoolInfo
            NLP.sendResponse(self, response)

        # 查询个人信息
        if action == CONST.PERSONAL_INFO:
            print("用户", self.id, "请求查询个人信息")
            PersonalInfo = AD.getPersonalInfo(self.id, self.Db_Conn)
            response = None
            if PersonalInfo is False:
                response = CONST.FALSE + '+' + CONST.PERSONAL_INFO
            else:
                PersonalInfo = NLP.Packge(PersonalInfo)
                print(PersonalInfo)
                response = CONST.PERSONAL_INFO + '+' + PersonalInfo
            NLP.sendResponse(self, response)

        # # 发送验证码
        # if action == CONST.GET_VERIFICATION:
        #     self.verif = VF.geneVerif()
        #     _email = AD.getEmail(self.id, self.Db_Conn)
        #     state = VF.sendmail(_email, self.verif)
        #     response = None
        #     if state:
        #         response = CONST.TRUE + '+' + CONST.GET_VERIFICATION
        #     else:
        #         response = CONST.FALSE + '+' + CONST.GET_VERIFICATION
        #     NLP.sendResponse(self, response)

        # 绑定邮箱获取验证码
        if action == CONST.BIND_GET_VF:
            self.verif = VF.geneVerif()
            _email = requestList[0]
            state = VF.sendmail(_email, self.verif)
            response = None
            if state:
                response = CONST.TRUE + '+' + CONST.BIND_GET_VF
                self.bind_email = requestList[0]
            else:
                response = CONST.FALSE + '+' + CONST.BIND_GET_VF
            NLP.sendResponse(self, response)

        # 绑定邮箱
        if action == CONST.BIND:
            _input_email = requestList[0]
            _vf = requestList[1]
            response = None
            if _input_email == self.bind_email and _vf == self.verif:
                print(self.bind_email)
                state = AD.addEmail(self.id, self.Db_Conn, self.bind_email)
                if state:
                    response = CONST.TRUE + '+' + CONST.BIND
                else:
                    response = CONST.FALSE + '+' + CONST.BIND
            else:
                response = CONST.FALSE + '+' + CONST.BIND
            NLP.sendResponse(self, response)

        # 忘记密码获取验证码
        if action == CONST.FORGET_GET_VF:
            self.id = requestList[0]
            _email = AD.getEmail(self.id, self.Db_Conn)
            response = None
            if _email is False:
                response = CONST.FALSE + '+' + CONST.FORGET_GET_VF
            else:
                self.verif = VF.geneVerif()
                state = VF.sendmail(_email, self.verif)
                if state:
                    response = CONST.TRUE + '+' + CONST.FORGET_GET_VF
                else:
                    response = CONST.FALSE + '+' + CONST.FORGET_GET_VF
            NLP.sendResponse(self, response)

        # 忘记密码
        if action == CONST.FORGET_PASSWORD:
            _id = requestList[0]
            _password = requestList[1]
            _vf = requestList[2]
            response = None
            if not _id == self.id or not _vf == self.verif:
                response = CONST.FALSE + '+' + CONST.FORGET_PASSWORD
            else:
                result = AD.modifyPasswordByEmail(
                    self.id, self.Db_Conn, _password)
                if result is False:
                    response = CONST.FALSE + '+' + CONST.FORGET_PASSWORD
                elif result is True:
                    response = CONST.TRUE + '+' + CONST.FORGET_PASSWORD
            NLP.sendResponse(self, response)

        # 修改密码
        if action == CONST.MODIFY_PASSWORD:
            result = AD.modifyPassword(self.id, self.Db_Conn, requestList)
            response = None
            if result is False:
                response = CONST.FALSE + '+' + CONST.MODIFY_PASSWORD
            elif result is True:
                response = CONST.TRUE + '+' + CONST.MODIFY_PASSWORD
            NLP.sendResponse(self, response)

        # TODO
        # 补充对其他请求的响应

    # 进行链接关闭后的一些处理
    def connClosed(self):
        self.Db_Conn.close()
        print("关闭连接：", self.peerAddress().toString(), "\n")
        print("等待链接...")
